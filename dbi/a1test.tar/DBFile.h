#pragma once
#include <string>
#include "File.h"

using std::string;
enum fType {heap, sorted, tree};
struct DBFileInterface
{
	enum wMode {reading,writing};
	struct StartUp {OrderMaker *o; int l;};

	virtual void MoveFirst() = 0;
	virtual void Add (Record &addMe) = 0;
	virtual int GetNext (Record &fetchMe) = 0;
	virtual int GetNext (Record &fetchMe, CNF &applyMe, Record  &literal) = 0;
	virtual int Create (char *name, fType myType, void *startup) = 0;
	virtual int Open (char *name) = 0;
	virtual int Close () = 0;
	virtual void Load (Schema &mySchema, char *loadMe) = 0;
};


//TODO what happen if getnext is called before the first page is persistent
//what happen if getnext is called while the last page is not persistent
//need to add mode_
class DBFileHeap: public DBFileInterface
{
private:
	Page page_;
	File file_;
	wMode mode_;
	int pageIndex_; //"pointer" to the current page in current file
public:
	DBFileHeap() 
	{
		pageIndex_ = 0;
		mode_ = reading;
	};
	~DBFileHeap() 
	{
	};
	File& GetFileInstance()
	{
		return file_;
	}

	//Each DBFile instance has a �pointer� to the current record in the file. By default, this 
	//pointer is at the first record in the file, but it can move in response to record retrievals. 
	//The following function forces the pointer to correspond to the first record in the file: 
	void MoveFirst()
	{
		MoveFirst(0);
	}
	void MoveFirst(int pageIndex)
	{
		CheckRAW();
		pageIndex_ = pageIndex;
		if(file_.GetLength() == 0) //if there is no page in the file, just make sure current page is empty
		{
			page_.EmptyItOut();
		}
		else//otherwise, get the first page
		{
			file_.GetPage(&page_,pageIndex_);
		}

	}

	void PersistentPage()
	{
		//?don't understand
			file_.AddPage(&page_,pageIndex_);
			page_.EmptyItOut();
			pageIndex_++;
	}
	void CheckRAW()
	{
		if(mode_ == writing)
		{
			if(!IsEmpty())
				PersistentPage();
			mode_ = reading;
		}
	}

	void Add (Record &addMe)
	{
		if(mode_ == reading) //should fetch the last page first
		{
			mode_ = writing;		
		}
		if(!page_.Append(&addMe))	
		{
			PersistentPage();
			if(!page_.Append(&addMe))
			{
				printf("page_.Append failed twice\n");
				exit(1);
			}
		}
	}
	bool IsEmpty()
	{
		return (file_.GetLength() == 0 && page_.GetNumRecs() == 0);
	}

	//GetNext simply gets the next record from the 
	//file and returns it to the user, where �next� is defined to be relative to the current location 
	//of the pointer. After the function call returns, the pointer into the file is incremented, so a 
	//subsequent call to GetNext won�t return the same record twice. The return value is an 
	//integer whose value is zero if and only if there is not a valid record returned from the 
	//function call (which will be the case, for example, if the last record in the file has already 
	//been returned).  
	int GetNext (Record &fetchMe)
	{
		CheckRAW();
		if(IsEmpty()) //if the file is empty, we are done
			return 0;
		//If this is the last record in current page, then do sth. Otherwise, fetch it.
		if(!page_.GetFirst(&fetchMe))
		{
			//if this is the last page in the file
			if(pageIndex_ == file_.GetLength() - 2)
			{
				//we are done
				return 0;
			}
			//otherwise
			pageIndex_++;
			page_.EmptyItOut();
			//Get next page frome file. This operation will crash the program, if no more page is available
			file_.GetPage(&page_,pageIndex_);

			if(!page_.GetFirst(&fetchMe))
			{
				printf("page_.GetFirst failed twice. New page is empty?\n");
				exit(1);				
			}
		}
		return 1;	
	}

	//GetNext also accepts a selection predicate (this is a conjunctive 
	//normal form expression). It returns the next record in the file that is accepted by the 
	//selection predicate. The literal record is used to check the selection predicate, and is 
	//created when the parse tree for the CNF is processed. 
	int GetNext (Record &fetchMe, CNF &applyMe, Record  &literal)
	{
		Record temp;
		ComparisonEngine comp;
		while(GetNext(temp) > 0)
		if (comp.Compare (&temp, &literal, &applyMe))
		{
			fetchMe.Consume(&temp);			
			return 1;
		}
		return 0;	
	}

	/*	Create: The first 
	parameter to this function is a text string that tells you where the binary data is physically 
	to be located � you should store the actual database data using the File class from 
	File.h. If you need to store any meta-data so that you can open it up again in the future 
	(such as the type of the file when you re-open it) as I indicated above, you can store this 
	in an associated text file � just take name and append some extension to it, such as 
	.header, and write your meta-data to that file.
	The second parameter to the Create function tells you the type of the file. In 
	DBFile.h, you should define an enumeration called myType with three possible 
	values: heap, sorted, and tree. When the DBFile is created, one of these three 
	values is passed to Create to tell the file what type it will be. In this assignment, you 
	obviously only have to deal with the heap case. Finally, the last parameter to Create is 
	a dummy parameter that you won�t use for this assignment, but you will use for 
	assignment two. The return value from Create is a 1 on success and a zero on failure. */
	int Create (char *name, fType myType, void *startup)
	{
		pageIndex_ = 0;

		mode_ = reading;
		if(myType == heap)
		{
			file_.Open(0,name);

			return 1;
		}
		return 0;	
	}
	//Open: This function assumes that the DBFile already exists and has 
	//previously been created and then closed. The one parameter to this function is simply the 
	//physical location of the file. If your DBFile needs to know anything else about itself, it 
	//should have written this to an auxiliary text file that it will also open at startup. The return 
	//value is a 1 on success and a zero on failure. 
	int Open (char *name)
	{
		pageIndex_ = 0;
		mode_ = reading;
		file_.Open(1,name); //Open the file, not erase it
		return 1;	
	}
	//Close simply closes the file. The return value is a 1 on success and a zero on failure
	int Close ()
	{
		CheckRAW();
		return 	file_.Close();;
	}
	//Load function bulk loads the DBFile instance from a text file, appending 
	//new data to it using the SuckNextRecord function from Record.h. The character 
	//string passed to Load is the name of the data file to bulk load. 
	void Load (Schema &mySchema, char *loadMe)
	{
        FILE *tableFile = 0;
		tableFile = fopen (loadMe, "r");
		if(tableFile == 0)
		{
			printf("Failed to load file %s\n",loadMe);
			exit(1);
		}

        Record temp;

        // read in all of the records from the text file and see if they match
	// the CNF expression that was typed in
	int counter = 0;
        while (temp.SuckNextRecord (&mySchema, tableFile) == 1) {
			this->Add(temp);
		}

		fclose(tableFile);
	}

};


class DBFile : public DBFileInterface
{
private:
	DBFileInterface* me_;
	StartUp startup_;
	fType myType_;
public:
	DBFile()
	{
		startup_.o = new OrderMaker();
		me_ = 0;
	}
	~DBFile()
	{
		delete me_;
		delete startup_.o;
	}


	void MoveFirst()
	{
		me_->MoveFirst();
	}

	void Add (Record &addMe)
	{
		me_->Add(addMe);
	}

	int GetNext (Record &fetchMe)
	{
		return me_->GetNext(fetchMe);
	}

	int GetNext (Record &fetchMe, CNF &applyMe, Record  &literal)
	{
		return me_->GetNext(fetchMe,applyMe,literal);
	}

	int Create (char *name, fType myType, void *startup)
	{
		myType_ = myType;
		SetMeta(name,myType,startup);
		//do sth
		DBFactory(0);
		return me_->Create(name,myType,startup);

	
	}

	void SetMeta(char *name, fType myType, void* startup)
	{
		if(myType == heap)
			return;
		if(startup == 0)
		{
			printf("startup is empty\n");
			exit(1);
		}
		string fname(name);
		fname += ".meta";
		FILE* meta = fopen(fname.c_str(),"w");
		if(meta == 0)
		{
			printf("Cannot create file %s\n",name);
			exit(1);
		}
		//serialize myType
		fprintf(meta, "Type = %d\n",myType);
		//serialize runlen
		fprintf(meta, "runlen = %d\n",((StartUp*)startup)->l);
		//serialize order
		OrderMaker* o(((StartUp*)startup)->o);
		fprintf(meta,"[Ordermake]\n");
		fprintf(meta,"numAtts=%d\n",o->numAtts);
		for(int i = 0 ; i < o->numAtts;  i++)
			fprintf(meta,"%d,%d\n",o->whichAtts[i],o->whichTypes[i]);

		fclose(meta);
	}
	fType GetMeta(char* name)
	{
		string fname(name);
		fname += ".meta";
		FILE* meta = fopen(fname.c_str(),"r");
		if(meta == 0)
		{
			return heap; //if there is no meta file, this must be a heap file
		}
		//deserialize myType
		fscanf(meta, "Type = %d\n",&myType_);
		//deserialize runlen
		fscanf(meta, "runlen = %d\n", &startup_.l);
		//deserialize order
		fscanf(meta,"[Ordermake]\n");
		fscanf(meta,"numAtts=%d\n",&(startup_.o->numAtts));
		OrderMaker& o(*startup_.o);
		for(int i = 0 ; i < o.numAtts;  i++)
			fscanf(meta,"%d,%d\n",&o.whichAtts[i],&o.whichTypes[i]);

		fclose(meta);
		return myType_;
		
	}
	int Open (char *name)
	{
		myType_ = GetMeta(name);
		DBFactory(&startup_);
		return me_->Open(name);
	
	}
	int Close ()
	{
		return me_->Close();
	}
	void Load (Schema &mySchema, char *loadMe)
	{
		me_->Load(mySchema,loadMe);
	}
	void DBFactory(StartUp* startup);
};

#include "BigQ.h" //BigQ is in at this point. The reason is that it needs DBFileHeap as a writing iterator,
				//but BigQ is required by DBFileSorted. But we want to have only two .h without any .cpp
				//So one reasonable choice is to put it here. As a result, it is the real layout of BigQ.h+DBFile.h
				//no matter which one is included in what order.

class DBFileSorted : public DBFileInterface
{
private:
	DBFileHeap dbfh_;

	OrderMaker o_;
	OrderMaker bsOrder_;
	int runlen_;
	wMode mode_;
	BigQ* q_;
	Pipe *inPipe_, *outPipe_;
	string dbfileName_;
	bool getnextReady_;
	bool useBinarySearch_;
	Record r_; //used as the temp output of binary search
public:
	DBFileSorted(StartUp* startup) 
	{
		if(startup != 0)
		{
			OrderMaker* o(((StartUp*)startup)->o);
			o_.numAtts = o->numAtts;
			for(int i = 0 ; i <o_.numAtts ; i ++)
			{
				o_.whichAtts[i] = o->whichAtts[i];
				o_.whichTypes[i] = o->whichTypes[i];
			}
			runlen_ = ((StartUp*)startup)->l;
		}
		mode_ = reading;
		q_ = 0;
		inPipe_ = 0;
		outPipe_ = 0;
		getnextReady_ = false;
		useBinarySearch_ = false;

	};
	~DBFileSorted() 
	{
	};
	File& GetFileInstance()
	{
		printf("Illegal call for DBFileSorted\n");
		exit(1);
	}

	//Each DBFile instance has a �pointer� to the current record in the file. By default, this 
	//pointer is at the first record in the file, but it can move in response to record retrievals. 
	//The following function forces the pointer to correspond to the first record in the file: 
	void MoveFirst()
	{
		CheckRAW();
		dbfh_.MoveFirst();
		getnextReady_ = false;
		useBinarySearch_ = false;

	}

	void StopWriting()
	{

		inPipe_->ShutDown();

		string tempfile = dbfileName_;
		tempfile += ".old";
		dbfh_.Close();
		rename(dbfileName_.c_str(),tempfile.c_str());

		dbfh_.Create((char*)dbfileName_.c_str(),heap,0);

		DBFileHeap dbfh;
		dbfh.Open((char*)tempfile.c_str());

		Record r0,r1;
		dbfh.MoveFirst();
		Record *min(0);

		ComparisonEngine ceng;
		int empty0(1),empty1(1);
		//two way merge
		while(1)
		{
			if(r0.bits == 0)
			{
				if(empty0 != 0)
					empty0 = outPipe_->Remove(&r0);
			}
			if(r1.bits == 0)
			{
				if(empty1 != 0)
					empty1 = dbfh.GetNext(r1);
			}
			if(r0.bits == 0 && r1.bits == 0)
				min = 0;
			else if(r0.bits == 0) min = &r1;
			else if(r1.bits == 0) min = &r0;
			else
			{
				if(ceng.Compare(&r0,&r1,&o_) < 0)
					min = &r0;
				else
					min = &r1;
			}
			if(min == 0)
				break;
			dbfh_.Add(*min);
		}

		
		dbfh.Close();
		remove(tempfile.c_str());


		delete q_;
		delete inPipe_;
		delete outPipe_;
		q_ = 0;
		inPipe_ = 0;
		outPipe_ = 0;
	}
	void Add (Record &addMe)
	{
		if(mode_ == reading)
		{
			if((q_ != 0)||(inPipe_ != 0 )||(outPipe_ != 0))
			{
				printf("Illegal q_\n");
				exit(1);
			}
			int bufferSize(100);
			inPipe_ = new Pipe(bufferSize);
			outPipe_ = new Pipe(bufferSize);
			q_ = new BigQ(*inPipe_,*outPipe_,o_,runlen_);

			mode_ = writing;

		}
		else if(mode_ == writing)
		{
		
		
				
		}
		else
		{
			printf("Illegal mode\n");
			exit(1);
		}

		inPipe_->Insert(&addMe);

	}

	void CheckRAW()
	{
		if(mode_ == writing)
		{
			StopWriting();
			mode_ = reading;
		}
	}

	//GetNext simply gets the next record from the 
	//file and returns it to the user, where �next� is defined to be relative to the current location 
	//of the pointer. After the function call returns, the pointer into the file is incremented, so a 
	//subsequent call to GetNext won�t return the same record twice. The return value is an 
	//integer whose value is zero if and only if there is not a valid record returned from the 
	//function call (which will be the case, for example, if the last record in the file has already 
	//been returned).  
	int GetNext (Record &fetchMe)
	{
		CheckRAW();

		return dbfh_.GetNext(fetchMe);
	}

	void buildBinarySearchOrderMaker(CNF &applyMe)
	{
		bsOrder_.numAtts = 0;
		for(int i = 0 ; i < o_.numAtts ;  i++)
		{
			bool selected(false);
			for(int j = 0 ; j < applyMe.numAnds ; j++)
			{
				if(applyMe.orLens[j] != 1)
					continue;
				Comparison& clause(applyMe.orList[j][0]);
				if(clause.op != Equals)
					continue;
				if( clause.operand1 == Left && clause.whichAtt1 == o_.whichAtts[i] && clause.operand2 == Literal)
					selected = true;
				else if( clause.operand2 == Left && clause.whichAtt2 == o_.whichAtts[i] && clause.operand1 == Literal)
					selected = true;
			}
			if(!selected) break;
			int a = bsOrder_.numAtts;
			bsOrder_.numAtts++;
			bsOrder_.whichAtts[a] = o_.whichAtts[i];
			bsOrder_.whichTypes[a] = o_.whichTypes[i];
		
		}
		useBinarySearch_ = true;
		if(bsOrder_.numAtts == 0)
			useBinarySearch_ = false;

	
	}
	Record* binarySearch(Record &literal)
	{
		ComparisonEngine ceng;


		File& f(dbfh_.GetFileInstance());
		Page p;
		Record r;
		int n = f.GetLength() - 1;

		int lo = 0, hi = n - 1, mid;
    
		while (lo < hi)
		{
			mid = (lo + hi) / 2;
			f.GetPage(&p,mid);
			if( p.GetFirst(&r) == 0)
			{
				printf("Empty page\n");
				exit(1);
			}
			if (ceng.Compare(&r,&literal,&bsOrder_) >= 0)
				hi = mid;
			else
				lo = mid + 1;    
			if(lo == hi - 1)
				break;
		}

		int index;
		Page h;
		Page l;
		f.GetPage(&h,hi);
		h.GetFirst(&r);
		//Now we have three cases,
		if(ceng.Compare(&r,&literal,&bsOrder_) < 0) //if hi is still lower than literal
		{
			//Linear scan the entire high page
			index = hi;
		}
		else 
		{
			f.GetPage(&l,lo);
			l.GetFirst(&r);
			if(ceng.Compare(&r,&literal,&bsOrder_) > 0) //if low is still higher or equal than literal
			{
				//we are done.
				return 0;
			}
			else
			{
				//Linear scan the entire low page
				index = lo;
			}

		
		}
		dbfh_.MoveFirst(index);
		while(dbfh_.GetNext(r_))
		{
			int gl = ceng.Compare(&r_,&literal,&bsOrder_);
			if( gl == 0)
			{
				return &r_;
			}
			if(gl > 0)
				return 0;
		}
		return 0;

	}
	//GetNext also accepts a selection predicate (this is a conjunctive 
	//normal form expression). It returns the next record in the file that is accepted by the 
	//selection predicate. The literal record is used to check the selection predicate, and is 
	//created when the parse tree for the CNF is processed. 
	int GetNext (Record &fetchMe, CNF &applyMe, Record  &literal)
	{
		CheckRAW();

		Record temp,*r;
		ComparisonEngine comp;

		if(!getnextReady_)
		{
			//prepare ordermaker
			buildBinarySearchOrderMaker(applyMe);


			if(useBinarySearch_)
			{
			//perform binary search
			r = binarySearch(literal);


			getnextReady_ = true;
			if(r == 0)
				return 0;

			if (comp.Compare (r, &literal, &applyMe))
			{
				fetchMe.Consume(r);
				return 1;
			}
			}
		}

		while(GetNext(temp) > 0)
		{
			if (comp.Compare (&temp, &literal, &applyMe))
			{
				fetchMe.Consume(&temp);			
				return 1;
			}
			if(useBinarySearch_) //if we using binary search, once bsOrder_ is not satisfied, we are done 
			{
				if(comp.Compare(&temp,&literal,&bsOrder_) != 0)
					break;
			}
		}
		return 0;	

	}

	/*	Create: The first 
	parameter to this function is a text string that tells you where the binary data is physically 
	to be located � you should store the actual database data using the File class from 
	File.h. If you need to store any meta-data so that you can open it up again in the future 
	(such as the type of the file when you re-open it) as I indicated above, you can store this 
	in an associated text file � just take name and append some extension to it, such as 
	.header, and write your meta-data to that file.
	The second parameter to the Create function tells you the type of the file. In 
	DBFile.h, you should define an enumeration called myType with three possible 
	values: heap, sorted, and tree. When the DBFile is created, one of these tree 
	values is passed to Create to tell the file what type it will be. In this assignment, you 
	obviously only have to deal with the heap case. Finally, the last parameter to Create is 
	a dummy parameter that you won�t use for this assignment, but you will use for 
	assignment two. The return value from Create is a 1 on success and a zero on failure. */
	int Create (char *name, fType myType, void *startup)
	{
		dbfileName_ = name;
		OrderMaker* o(((StartUp*)startup)->o);
		o_.numAtts = o->numAtts;
		for(int i = 0 ; i <o_.numAtts ; i ++)
		{
			o_.whichAtts[i] = o->whichAtts[i];
			o_.whichTypes[i] = o->whichTypes[i];
		}
		runlen_ = ((StartUp*)startup)->l;

		if(myType == sorted)
		{
			dbfh_.Create(name,heap,0);
			mode_ = reading; //This must be reading. Otherwise, q_ will not be created in next add function call.

			return 1;
		}
		return 0;	
	}
	//Open: This function assumes that the DBFile already exists and has 
	//previously been created and then closed. The one parameter to this function is simply the 
	//physical location of the file. If your DBFile needs to know anything else about itself, it 
	//should have written this to an auxiliary text file that it will also open at startup. The return 
	//value is a 1 on success and a zero on failure. 
	int Open (char *name)
	{
		dbfileName_ = name;
		dbfh_.Open(name); //Open the file, not erase it
		mode_ = reading;

		return 1;	
	}
	//Close simply closes the file. The return value is a 1 on success and a zero on failure
	int Close ()
	{
		CheckRAW();
		return 	dbfh_.Close();;
	}
	//Load function bulk loads the DBFile instance from a text file, appending 
	//new data to it using the SuckNextRecord function from Record.h. The character 
	//string passed to Load is the name of the data file to bulk load. 
	void Load (Schema &mySchema, char *loadMe)
	{
        FILE *tableFile = 0;
		tableFile = fopen (loadMe, "r");
		if(tableFile == 0)
		{
			printf("Failed to load file %s\n",loadMe);
			exit(1);
		}

        Record temp;

        // read in all of the records from the text file and see if they match
	// the CNF expression that was typed in
		int counter = 0;
        while (temp.SuckNextRecord (&mySchema, tableFile) == 1) {
			this->Add(temp);
		}

		fclose(tableFile);

	}

};

inline	void DBFile::DBFactory(StartUp* startup)
	{
		if(myType_ == heap)
			me_ = new DBFileHeap();
		else if(myType_ == sorted)
			me_ = new DBFileSorted(startup);
		else
		{
				printf("tree file is not supported  yet\n");
				exit(1);
		}
	}
